package organiser.gui;

public interface Resizable {
	public void manageResize();
}

