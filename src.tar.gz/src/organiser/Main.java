package organiser;

import organiser.gui.GUI;

public class Main {
	public static void main(String[] args) {
		new GUI();
	}
}
