package organiser.testing;

import static org.junit.Assert.fail;

import java.util.ArrayList;

import javax.swing.SwingUtilities;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import organiser.business.Record;

public class GUITest {
	private TestGUI gui;

	@Before
	public void setUp() throws Exception {
		gui = new TestGUI();
	}

	@Test
	public void testGUIAddRemoveUndoRecords() {
		final GUITest t = this;
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				@Override
				public void run() {
					try {
						// TODO Auto-generated method stub
						int startSize = gui.getLoadedRecords().size();
						ArrayList<Record> added = new ArrayList<Record>();
						for (int i = 1; i < 6; i++) {
							added.add(gui.addNewRecord());
							Assert.assertTrue(startSize + i == gui.getLoadedRecords().size());
						}
						for(int i = 1; i < added.size()+1; i++){
							gui.deleteCurrentRecord();
							Assert.assertTrue(startSize + added.size() - i == gui.getLoadedRecords().size());
							Assert.assertTrue(i == gui.getDeletedRecords().size());
						}
						for(int i = 1; i < added.size()+1; i++){
							gui.selectedRecord.curRecord.setNeedsSave(false);
							gui.undoRecordDelete();
							Assert.assertTrue(startSize + i == gui.getLoadedRecords().size());
						}
						for(int i = 1; i < added.size()+1; i++){
							gui.deleteCurrentRecord();
							Assert.assertTrue(startSize + added.size() - i == gui.getLoadedRecords().size());
							Assert.assertTrue(i == gui.getDeletedRecords().size());
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						fail("Exception occurred : " + e.getMessage());
					}
				}
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fail("Exception thrown: " + e.getMessage());
		}
	}
}
