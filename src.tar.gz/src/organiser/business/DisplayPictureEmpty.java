package organiser.business;

import javax.swing.JPanel;

public class DisplayPictureEmpty extends DisplayPicture {
	public DisplayPictureEmpty(){
		super();
	}
	@Override
	public JPanel Display(){
		return null;
	}
}
